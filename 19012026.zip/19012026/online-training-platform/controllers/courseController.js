const { Course } = require("../models");

exports.createCourse = async (req, res) => {
  try {
    const course = await Course.create(req.body);
    res.status(201).json(course);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getCourses = async (req, res) => {
  const courses = await Course.findAll();
  res.json(courses);
};

exports.getCourseById = async (req, res) => {
  const course = await Course.findByPk(req.params.id);
  if (!course) return res.status(404).json({ message: "Not Found" });
  res.json(course);
};

exports.updateCourse = async (req, res) => {
  await Course.update(req.body, { where: { id: req.params.id } });
  res.json({ message: "Updated" });
};

exports.deleteCourse = async (req, res) => {
  await Course.destroy({ where: { id: req.params.id } });
  res.json({ message: "Deleted" });
};
