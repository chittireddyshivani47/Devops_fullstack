const { DataTypes } = require("sequelize");
const sequelize = require("../database");

const Enrollment = sequelize.define("Enrollment", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  studentName: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

module.exports = Enrollment;
