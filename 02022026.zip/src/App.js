import React from "react";
import StudentCard from "./StudentCard";

function App() {
  const students = [
    { name: "Arjun", roll: "CS101", marks: { math: 88, science: 92, english: 78 } },
    { name: "Meera", roll: "CS102", marks: { math: 76, science: 81, english: 89 } },
    { name: "Varun", roll: "CS103", marks: { math: 91, science: 95, english: 84 } },
    { name: "Sahana", roll: "CS104", marks: { math: 65, science: 72, english: 70 } },
    { name: "Aravind", roll: "CS105", marks: { math: 55, science: 48, english: 50 } }
  ];

  return (
    <div style={styles.page}>
      <h1>Student Marks Cards</h1>
      <div style={styles.cardContainer}>
        {students.map((student, index) => (
          <StudentCard
            key={index}
            name={student.name}
            roll={student.roll}
            marks={student.marks}
          />
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "100vh", // centers vertically
    background: "#f5f5f5"
  },
  cardContainer: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "20px"
  }
};

export default App;
