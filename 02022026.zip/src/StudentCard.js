import React from "react";

const StudentCard = ({ name, roll, marks }) => {
  const { math, science, english } = marks;

  const total = math + science + english;

  // Determine grade
  const grade =
    total >= 270
      ? "A"
      : total >= 225
      ? "B"
      : total >= 180
      ? "C"
      : "D";

  // Highlight color based on total marks
  const cardStyle = {
    ...styles.card,
    backgroundColor:
      total >= 270
        ? "#c8e6c9" // light green
        : total >= 225
        ? "#fff9c4" // light yellow
        : "#ffcdd2" // light red
  };

  return (
    <div style={cardStyle}>
      <h2>{name}</h2>
      <p><strong>Roll:</strong> {roll}</p>
      <p><strong>Math:</strong> {math} | <strong>Science:</strong> {science} | <strong>English:</strong> {english}</p>
      <p><strong>Total:</strong> {total}</p>
      <p><strong>Grade:</strong> {grade}</p>
    </div>
  );
};

const styles = {
  card: {
    border: "2px solid #444",
    padding: "12px",
    margin: "12px",
    borderRadius: "8px",
    width: "320px",
    boxShadow: "2px 2px 6px rgba(0,0,0,0.2)"
  }
};

export default StudentCard;
