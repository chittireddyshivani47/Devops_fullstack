const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// Home route
app.get("/", (req, res) => {
  res.send("Personal Finance Tracker Backend is Running 🚀");
});

let expenses = [];
let income = [];

// Dashboard summary
app.get("/dashboard", (req, res) => {
  const totalIncome = income.reduce((sum, i) => sum + i.amount, 0);
  const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);

  res.json({
    totalIncome,
    totalExpense,
    balance: totalIncome - totalExpense
  });
});

// Add expense
app.post("/expenses", (req, res) => {
  expenses.push(req.body);
  res.json({ message: "Expense added" });
});

// Add income
app.post("/income", (req, res) => {
  income.push(req.body);
  res.json({ message: "Income added" });
});

app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});