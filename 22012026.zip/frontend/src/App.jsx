import React, { useState, useEffect } from 'react';
import EventList from './components/EventList';
import EventForm from './components/EventForm';
import EventDetails from './components/EventDetails';
import Stats from './components/Stats';
import './App.css';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: '', category: '', search: '' });
  const [stats, setStats] = useState(null);

  // Fetch all events
  const fetchEvents = async () => {
    try {
      setLoading(true);
      const queryParams = new URLSearchParams();
      if (filter.status) queryParams.append('status', filter.status);
      if (filter.category) queryParams.append('category', filter.category);
      if (filter.search) queryParams.append('search', filter.search);

      const response = await fetch(`${API_URL}/events?${queryParams}`);
      const data = await response.json();
      
      if (data.success) {
        setEvents(data.data);
      }
    } catch (error) {
      console.error('Error fetching events:', error);
      alert('Failed to fetch events');
    } finally {
      setLoading(false);
    }
  };

  // Fetch statistics
  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_URL}/stats`);
      const data = await response.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  useEffect(() => {
    fetchEvents();
    fetchStats();
  }, [filter]);

  // CREATE Event
  const createEvent = async (eventData) => {
    try {
      const response = await fetch(`${API_URL}/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData)
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert('Event created successfully!');
        fetchEvents();
        fetchStats();
        setShowForm(false);
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error creating event:', error);
      alert('Failed to create event');
    }
  };

  // UPDATE Event
  const updateEvent = async (id, eventData) => {
    try {
      const response = await fetch(`${API_URL}/events/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData)
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert('Event updated successfully!');
        fetchEvents();
        fetchStats();
        setShowForm(false);
        setEditingEvent(null);
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error updating event:', error);
      alert('Failed to update event');
    }
  };

  // DELETE Event
  const deleteEvent = async (id) => {
    if (!window.confirm('Are you sure you want to delete this event?')) {
      return;
    }

    try {
      const response = await fetch(`${API_URL}/events/${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert('Event deleted successfully!');
        fetchEvents();
        fetchStats();
        setSelectedEvent(null);
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error deleting event:', error);
      alert('Failed to delete event');
    }
  };

  // Add Participant
  const addParticipant = async (eventId, participant) => {
    try {
      const response = await fetch(`${API_URL}/events/${eventId}/participants`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(participant)
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert('Participant added successfully!');
        fetchEvents();
        if (selectedEvent && selectedEvent._id === eventId) {
          setSelectedEvent(data.data);
        }
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error adding participant:', error);
      alert('Failed to add participant');
    }
  };

  // Remove Participant
  const removeParticipant = async (eventId, participantId) => {
    try {
      const response = await fetch(`${API_URL}/events/${eventId}/participants/${participantId}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert('Participant removed successfully!');
        fetchEvents();
        if (selectedEvent && selectedEvent._id === eventId) {
          setSelectedEvent(data.data);
        }
      } else {
        alert(`Error: ${data.message}`);
      }
    } catch (error) {
      console.error('Error removing participant:', error);
      alert('Failed to remove participant');
    }
  };

  const handleEdit = (event) => {
    setEditingEvent(event);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingEvent(null);
  };

  return (
    <div className="App">
      <header className="header">
        <div className="header-content">
          <h1>📅 Event Management System</h1>
          <p>Manage your events with MongoDB CRUD operations</p>
        </div>
      </header>

      {stats && <Stats stats={stats} />}

      <div className="container">
        <div className="toolbar">
          <button 
            className="btn btn-primary"
            onClick={() => setShowForm(true)}
          >
            + Create New Event
          </button>

          <div className="filters">
            <select 
              value={filter.status}
              onChange={(e) => setFilter({...filter, status: e.target.value})}
            >
              <option value="">All Status</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>

            <select 
              value={filter.category}
              onChange={(e) => setFilter({...filter, category: e.target.value})}
            >
              <option value="">All Categories</option>
              <option value="Conference">Conference</option>
              <option value="Workshop">Workshop</option>
              <option value="Seminar">Seminar</option>
              <option value="Meetup">Meetup</option>
              <option value="Webinar">Webinar</option>
              <option value="Other">Other</option>
            </select>

            <input
              type="text"
              placeholder="Search events..."
              value={filter.search}
              onChange={(e) => setFilter({...filter, search: e.target.value})}
              className="search-input"
            />
          </div>
        </div>

        <div className="main-content">
          <div className="events-section">
            {loading ? (
              <div className="loading">Loading events...</div>
            ) : (
              <EventList 
                events={events}
                onSelectEvent={setSelectedEvent}
                onEdit={handleEdit}
                onDelete={deleteEvent}
              />
            )}
          </div>

          {selectedEvent && (
            <div className="details-section">
              <EventDetails 
                event={selectedEvent}
                onClose={() => setSelectedEvent(null)}
                onEdit={() => handleEdit(selectedEvent)}
                onDelete={() => deleteEvent(selectedEvent._id)}
                onAddParticipant={addParticipant}
                onRemoveParticipant={removeParticipant}
              />
            </div>
          )}
        </div>
      </div>

      {showForm && (
        <EventForm
          event={editingEvent}
          onSubmit={editingEvent ? 
            (data) => updateEvent(editingEvent._id, data) : 
            createEvent
          }
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
}

export default App;
